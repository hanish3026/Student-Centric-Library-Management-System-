package com.lms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.module.LibrarianLogin;

public interface LibrarianRepository extends JpaRepository<LibrarianLogin, Long>{
	
}
