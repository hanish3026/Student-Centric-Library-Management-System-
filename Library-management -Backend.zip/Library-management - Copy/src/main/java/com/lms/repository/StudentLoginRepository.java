package com.lms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.module.StudenLogin;

public interface StudentLoginRepository extends JpaRepository<StudenLogin,Long>{

}
