package com.lms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lms.module.BookIssuing;
@Repository
public interface BookIssueingRepository extends JpaRepository<BookIssuing, Long>{
	List<BookIssuing> findByStudenID(Long studenID);
	}

