package com.lms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.module.AvailableBooks;

public interface AvailableBooksRepository extends JpaRepository<AvailableBooks,Long> {

}
