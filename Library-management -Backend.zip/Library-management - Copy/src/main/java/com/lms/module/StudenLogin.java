package com.lms.module;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "StudenLogin")
public class StudenLogin {
    @Id
    @Column(name = "studentId" , nullable = false)
    private Long studentId;
    
    @Column(name = "password", nullable = false)
    private String password;

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public StudenLogin(Long studentId, String password) {
		super();
		this.studentId = studentId;
		this.password = password;
	}

	@Override
	public String toString() {
		return "StudenLogin [studentId=" + studentId + ", password=" + password + ", getStudentId()=" + getStudentId()
				+ ", getPassword()=" + getPassword() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	public StudenLogin() {
		super();
		// TODO Auto-generated constructor stub
	}
}
