package com.lms.module;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "LibrarianLogin")
public class LibrarianLogin {
    @Id
    @Column(name = "librarianId" , nullable = false)
    private Long librarianId;
    
    @Column(name = "password", nullable = false)
    private String password;

	public Long getLibrarianId() {
		return librarianId;
	}

	public void setLibrarianId(Long librarianId) {
		this.librarianId = librarianId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LibrarianLogin(Long librarianId, String password) {
		super();
		this.librarianId = librarianId;
		this.password = password;
	}

	@Override
	public String toString() {
		return "LibrarianLogin [librarianId=" + librarianId + ", password=" + password + ", getLibrarianId()="
				+ getLibrarianId() + ", getPassword()=" + getPassword() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

	public LibrarianLogin() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
