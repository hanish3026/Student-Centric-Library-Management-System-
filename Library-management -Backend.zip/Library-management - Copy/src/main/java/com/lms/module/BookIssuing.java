package com.lms.module;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "IssedBook")
public class BookIssuing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long ID;
    public BookIssuing(Long iD, Long studenID, String bookID, String bookName, String issueDate, String returnDate,
			Long fineAmount) {
		super();
		ID = iD;
		this.studenID = studenID;
		this.bookID = bookID;
		this.bookName = bookName;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.fineAmount = fineAmount;
	}

	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}

	@Column(name = "StudentID" , nullable = false)
    private Long studenID;
    
    @Column(name = "BookId", nullable = false)
    private String bookID;
    
    @Column(name = "BookName", nullable = false)
    private String bookName;
    
    @Column(name = "IssueDate", nullable = false)
    private String issueDate;
    
    @Column(name = "ReturnDate", nullable = false)
    private String returnDate;
    
    @Column(name = "FineAmount", nullable = false)
    private Long fineAmount;

	public Long getStudenID() {
		return studenID;
	}

	public void setStudenID(Long studenID) {
		this.studenID = studenID;
	}

	public String getBookID() {
		return bookID;
	}

	public void setBookID(String bookID) {
		this.bookID = bookID;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}

	public Long getFineAmount() {
		return fineAmount;
	}

	public void setFineAmount(Long fineAmount) {
		this.fineAmount = fineAmount;
	}

	public BookIssuing() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookIssuing(Long studenID, String bookID, String bookName, String issueDate, String returnDate,
			Long fineAmount) {
		super();
		this.studenID = studenID;
		this.bookID = bookID;
		this.bookName = bookName;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.fineAmount = fineAmount;
	}

	@Override
	public String toString() {
		return "BookIssuing [ID=" + ID + "]";
	}
}
