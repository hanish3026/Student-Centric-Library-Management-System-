package com.lms.module;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "AvailableBooks")
public class AvailableBooks {
    @Id
   
    @Column(name = "BookId" , nullable = false)
    private Long bookId;
    
    @Column(name = "BookName", nullable = false)
    private String bookName;
    
    @Column(name = "Author", nullable = false)
    private String author;
    
    @Column(name = "Status", nullable = false)
    private String Status;
    
	public AvailableBooks(String status) {
		super();
		Status = status;
	}


	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public AvailableBooks(Long bookId, String bookName, String author) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
	}

	@Override
	public String toString() {
		return "AvailableBooks [Status=" + Status + "]";
	}

	public AvailableBooks() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
