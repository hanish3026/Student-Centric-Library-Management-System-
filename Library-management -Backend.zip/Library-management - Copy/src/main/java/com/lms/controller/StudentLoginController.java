package com.lms.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.module.StudenLogin;
import com.lms.repository.StudentLoginRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("StudentLogin")
@RestController
public class StudentLoginController {
	@Autowired
	StudentLoginRepository studentLoginRepository;
	
	@GetMapping
	public List<StudenLogin> getMethodName() {
		return studentLoginRepository.findAll();
	}
	
}
