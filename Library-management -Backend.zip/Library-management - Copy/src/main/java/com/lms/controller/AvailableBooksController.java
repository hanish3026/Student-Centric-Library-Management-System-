package com.lms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.lms.module.AvailableBooks;
import com.lms.repository.AvailableBooksRepository;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;



@RestControllerAdvice
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("Books")
@RestController
public class AvailableBooksController {
	@Autowired
	AvailableBooksRepository availableBooksRepository;
	
	@GetMapping
	public List<AvailableBooks> getMethodName() {
		return availableBooksRepository.findAll();
	}
	@PostMapping
	public String postMethodName(@RequestBody AvailableBooks books) {
		availableBooksRepository.save(books);
		return "Books Added Successfully";
	}
	@GetMapping("/{id}")
	public Optional<AvailableBooks> getBooksById(@PathVariable("id") Long id) {
	    return availableBooksRepository.findById(id); // This will return a List<AvailableBooks> if your query supports it
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<AvailableBooks> putMethodName(@PathVariable("id") Long id , @RequestBody AvailableBooks entity) {
		Optional<AvailableBooks> oldbooks = availableBooksRepository.findById(id);
		if(oldbooks.isPresent()) {
			AvailableBooks book = oldbooks.get();
			book.setBookId(entity.getBookId());
			book.setBookName(entity.getBookName());
			book.setAuthor(entity.getAuthor());
			book.setStatus(entity.getStatus());
			availableBooksRepository.save(book);
			return ResponseEntity.ok(book);
		}else {
			return ResponseEntity.notFound().build();
		}
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteBooks(@PathVariable("id") Long id) {
	    Optional<AvailableBooks> book = availableBooksRepository.findById(id);
	    if (book.isPresent()) {
	        availableBooksRepository.deleteById(id);
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("SUCCESSFULLY DELETED");
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}


}
