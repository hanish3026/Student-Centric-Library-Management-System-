package com.lms.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.lms.module.BookIssuing;
import com.lms.repository.BookIssueingRepository;
@RestControllerAdvice
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("issuedBooks")
@RestController
public class IssueBookControler {
	@Autowired
	BookIssueingRepository bookIssueingRepository;

    @GetMapping()
    public List<BookIssuing> updateFines() {
        List<BookIssuing> books = bookIssueingRepository.findAll();
        LocalDate currentDate = LocalDate.now();
        long finePerDay = 10;

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        for (BookIssuing book : books) {
            try {
                LocalDate returnDate = LocalDate.parse(book.getReturnDate(), dateFormatter);

                if (currentDate.isAfter(returnDate)) {
                    int daysOverdue = currentDate.compareTo(returnDate);
                    book.setFineAmount(daysOverdue * finePerDay);
                } else {
                    book.setFineAmount(0L);
                }
            } catch (DateTimeParseException e) {
                // Handle invalid date formats
                System.err.println("Invalid date format for book: " + book.getBookName() + 
                                   ". Return Date: " + book.getReturnDate());
                book.setFineAmount(0L); // Default fine to 0 for invalid dates
            }
        }

        bookIssueingRepository.saveAll(books);

        return books;
    }
    
//    @GetMapping("/{studentId}")
//    public ResponseEntity<List<BookIssuing>> getBooksByStudentId(@PathVariable Long studentId) {
//        List<BookIssuing> books = bookIssueingRepository.findByStudentID(studentId);
//        if (books.isEmpty()) {
//            return ResponseEntity.noContent().build(); // Return 204 if no books are found
//        }
//        return ResponseEntity.ok(books); // Return the books in a 200 OK response
//    }
    
	@PostMapping
	public String postMethodName(@RequestBody BookIssuing books) {
		bookIssueingRepository.save(books);
		return "Books Issued Successfully";
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteBooks(@PathVariable("id") Long id) {
	    Optional<BookIssuing> book = bookIssueingRepository.findById(id);
	    if (book.isPresent()) {
	    	bookIssueingRepository.deleteById(id);
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("SUCCESSFULLY DELETED");
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}
	@PutMapping("/{id}")
	public ResponseEntity<BookIssuing> putMethodName(@PathVariable("id") Long id , @RequestBody BookIssuing entity) {
		Optional<BookIssuing> oldbooks = bookIssueingRepository.findById(id);
		if(oldbooks.isPresent()) {
			BookIssuing book = oldbooks.get();
			book.setBookName(entity.getBookName());
			book.setReturnDate(entity.getReturnDate());
			book.setFineAmount(entity.getFineAmount());
			bookIssueingRepository.save(book);
			return ResponseEntity.ok(book);
		}else {
			return ResponseEntity.notFound().build();
		}
	}
	@GetMapping("/{id}")
	public ResponseEntity<List<BookIssuing>> getByID(@PathVariable("id") Long id) {
	    // Find books by studentID
	    List<BookIssuing> books = bookIssueingRepository.findByStudenID(id);

	    // Return 404 if no books are found
	    if (books.isEmpty()) {
	        return ResponseEntity.notFound().build();
	    }

	    // Return the list of books with 200 OK
	    return ResponseEntity.ok(books);
	}
}
