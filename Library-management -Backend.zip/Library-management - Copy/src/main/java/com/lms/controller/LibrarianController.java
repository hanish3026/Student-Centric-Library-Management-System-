package com.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.module.LibrarianLogin;
import com.lms.repository.LibrarianRepository;
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("LibrarianLogin")
@RestController
public class LibrarianController {
	@Autowired
	LibrarianRepository librarianRepository;
	
	@GetMapping
	public List<LibrarianLogin> getMethodName() {
		return librarianRepository.findAll();
	}
	
}
